create table actors_history_scd (
    actor text,
    actorid text,
    start_date date,
    end_date date,
    quality_class quality_class,
    is_active boolean
);
